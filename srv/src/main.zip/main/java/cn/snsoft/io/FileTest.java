package cn.snsoft.io;

public class FileTest
{
	public static void main(String[] args)
	{
		
	}
}
