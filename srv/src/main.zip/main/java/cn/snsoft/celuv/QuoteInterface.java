package cn.snsoft.celuv;

public interface QuoteInterface
{
	public int getPrice(int price);
}
