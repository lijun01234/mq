package cn.snsoft.celuv;

public class QuoteV1 implements QuoteInterface
{
	@Override
	public int getPrice(int price)
	{
		return 0;
	}
}
