package cn.snsoft.db;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import snsoft.commons.sql.JdbcURL;
import snsoft.commons.util.ArrayUtils;
import snsoft.commons.util.StrUtils;
import snsoft.util.data.WorkSpace;
import cn.snsoft.util.XMLUtil;
import cn.snsoft.util.XMLUtil.ElementIterator;
import com.sun.org.apache.xml.internal.security.utils.XMLUtils;
public class WorkSpace
{
	private String			id;
	private String			title;
	private List<WorkSpace>	workSpaces;

	static public synchronized List<WorkSpace> load()
	{
		java.util.List<WorkSpace> list = new ArrayList();
		java.io.InputStream is = null;
		try
		{
			is = WorkSpace.class.getResourceAsStream("snconfig/WorkSpace.xml");
			if (is == null)
			{
				String s = "未定义账套文件!";
				throw new RuntimeException(s);
			}
			final Document doc = XMLUtil.parse(is);
			final org.w3c.dom.Element rootE = doc.getDocumentElement();
			for (final Element wsE : XMLUtil.iteratorChileElements(rootE))
			{
				list.add(parseWorkspace(wsE, clusters));
			}
		} catch (Throwable ex)
		{
			throw new RuntimeException(ex);
		} finally
		{
			if (is != null)
				try
				{
					is.close();
				} catch (Throwable ex)
				{
					throw new RuntimeException(ex);
				}
		}
		return list;
	}

	private static WorkSpace parseWorkspace(final org.w3c.dom.Element wsE, java.util.Map<String,String[]> clusters)
	{
		String id = wsE.getAttribute("id"); // 帐套 ID
		String title = wsE.getAttribute("title");
		if (title != null && title.length() == 0)
			title = null;
		String defaultURL = null;
		int defaultUtlFlags = 0;
		final java.util.List<String> dsidList = new java.util.ArrayList();
		final java.util.List<String> urlList = new java.util.ArrayList();
		final snsoft.commons.util.IntVector xflagsList = new snsoft.commons.util.IntVector();
		//for(final XmlElement e : wsE.subElements )
		final java.util.List<org.w3c.dom.Element> dsElememts = XMLUtils.getChildElements(wsE);
		for (final org.w3c.dom.Element e : dsElememts)//XMLUtils.getChildElements(wsE))
		{
			//wsE.r
			String dsID = XMLUtils.removeAttribute(e, "id");//e.removeAttribute("id");
			String url = XMLUtils.removeAttribute(e, "url");//e.removeAttribute("url");
			final String user = XMLUtils.removeAttribute(e, "user");
			String password = XMLUtils.removeAttribute(e, "password");
			if (password != null && password.length() > 2 && password.charAt(0) == '`' && password.charAt(password.length() - 1) == '`')
				try
				{
					password = StrUtils.convertPasswordString(password, "UTF-8", false);
				} catch (java.io.IOException ex)
				{
					throw new java.lang.IllegalArgumentException(ex);
				}
			String dsClusterID = XMLUtils.removeAttribute(e, "clusterid");// e.removeAttribute("clusterid"); // 同一个集群：
			final String jdbcUrlPre = XMLUtils.removeAttribute(e, "jdbc.prefix");//e.removeAttribute("jdbc.prefix");
			int xflags = 0;
			final String objFlags = XMLUtils.removeAttribute(e, "xflags");
			final String objType = XMLUtils.removeAttribute(e, "type");
			if (objFlags != null && objFlags.trim().length() > 0)
				xflags = Integer.parseInt(objFlags.trim());
			final String objPort = XMLUtils.removeAttribute(e, "port");
			final String host = XMLUtils.removeAttribute(e, "host");
			final String database = XMLUtils.removeAttribute(e, "database");
			/*if( snsoft.TestConfig.test && "00_SNSOFT80_DEMO_TDS".equals(id) )
			{
				System.out.println(e.getAttributes());
			} */
			final java.util.Map<String,String> moreProps = new java.util.HashMap<>();
			// <datasource host = "127.0.0.1" port="1433" database="snsoft80_prewarn" user="sa" password="caoyuwu" type="sqlserver" />
			//for(final String k : e.getAttributes().keySet() )
			final org.w3c.dom.NamedNodeMap attrs = e.getAttributes();
			final int nattr = attrs.getLength();
			for (int i = 0; i < nattr; i++)
			{
				final org.w3c.dom.Node n = attrs.item(i);
				moreProps.put(n.getNodeName(), n.getNodeValue());
				//if( k.startsWith("props.") )
				//moreProps.put(k.substring(6), e.getAttribute(k) );
				//moreProps.put(k, e.getAttribute(k) );
			}
			if (url == null)
			{
				url = JdbcURL.toURL(JdbcURL.parseDBType(objType, 0), //Integer.parseInt(typeAttr,16),
						host, objPort == null ? 0 : Integer.parseInt(objPort), database, user, password, moreProps);
			} else
			// url!=null
			{
				url = JdbcURL.toURL(url, user, password, moreProps);
			}
			if (url == null)
				throw wspError(wsE);
			if (jdbcUrlPre != null)
			{
				// jdbc.prefix="remote:m0://127.0.0.1:8080/snsoft/"
				//jdbc:remote:m0://<server>:80/jdbc:inetdae:127.0.0.1:1433?database=sndata6_1&charset=GBK&user=sa&password=
				if (!url.startsWith("jdbc:"))
					throw wspError(wsE);
				url = "jdbc:" + jdbcUrlPre + url.substring(5);
				//url = rjdbcHost.indexOf("://")>=0 ? rjdbcHost+"/"+url.substring(5) : "jdbc:remote:m0://"+rjdbcHost+"/"+url.substring(5);
			}
			if (dsID == null || dsID.length() == 0 || "DEFAULT".equals(dsID = dsID.toUpperCase()))
			{
				defaultURL = url;
				defaultUtlFlags = xflags;
			} else
			{
				dsidList.add(dsID);
				urlList.add(url);
				xflagsList.add(xflags);
			}
			if (defaultURL == null)
				defaultURL = url;
			if (dsClusterID != null && clusters != null)
			{
				dsClusterID = dsClusterID.toUpperCase();
				String[] c = clusters.get(dsClusterID);
				c = ArrayUtils.addElement(c, url, true);
				clusters.put(dsClusterID, c);
				//	;//clusters.put(dsClusterID, c)
			}
		} // for(final XmlElement e : wsE.subElements )
			// wsE.qName.equals("workspace")
		if (!"workspace".equals(wsE.getTagName()) || dsElememts.size() == 0 || defaultURL == null)
			throw wspError(wsE);
		java.util.Map<String,String> xprops = null;
		final org.w3c.dom.NamedNodeMap attrs = wsE.getAttributes();
		int nattr = attrs.getLength();
		for (int i = 0; i < nattr; i++)
		{
			final org.w3c.dom.Node n = attrs.item(i);
			final String name = n.getNodeName();
			if (Arrays.binarySearch(stdWSAttrNames, name) < 0)
			{
				if (xprops == null)
					xprops = new HashMap();
				xprops.put(name, wsE.getAttribute(name));
			}
		}
		/* 
		
		*/
		return new WorkSpace(id, title, defaultURL, options, charSet, dsidList.size() == 0 ? null : dsidList.toArray(new String[dsidList.size()]), urlList.size() == 0 ? null
				: urlList.toArray(new String[urlList.size()]), xprops, defaultUtlFlags, xflagsList.toArray());
	}
}
